package zen6;
class MyException extends Exception {
	public MyException(String s)
	{
		super(s);
	}
}
public class Voter {
	int voterId;
	String name;
	int age;
	public Voter(int voterId, String name, int age) {
		super();
		this.voterId = voterId;
		this.name = name;
		try {
			if(age<18) {
				throw new MyException("Invalid age for voter");
			}else {
				this.age=age;
			}
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}
	public static void main(String[] args) {
		Voter vote = new Voter(1,"public1",17);
		//System.out.println(vote.voterId+" "+vote.name+" "+vote.age);
	}
}
