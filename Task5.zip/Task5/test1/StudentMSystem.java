package zen6;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StudentMSystem {
	int roll_no;
	String name;
	int age;
	String course;
	public StudentMSystem(int roll_no, String name, int age, String course) {
		super();
		this.roll_no = roll_no;
		//for name check
		Pattern p = Pattern.compile("[^a-z]", Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(name);
        boolean res = m.find();
        try {
        if (res) {
        	throw new MyException("Name Not Valid Exception");
        }else {
        	this.name = name;
        }
        }catch(Exception ex) {
        	System.out.println(ex.getMessage());
        }
        //for age check
		try {
			if(15 > age && age < 21) {
				throw new MyException("Age not within Range Exception");
			}else {
				this.age=age;
			}
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		this.course = course;
		//System.out.println(name+" "+age+" "+course+" "+roll_no);
	}
public static void main(String args[]) {
	StudentMSystem ob = new StudentMSystem(1, "a$", 11, "as");
}
}
