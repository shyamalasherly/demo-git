package zen4;

import java.util.Scanner;

public class XYZ {
	public static void main(String[] args) {
		Product[] prod = new Product[5];
		Scanner scanner = new Scanner(System.in);
		for (int i = 0; i < 5; i++) {
			System.out.println("Enter product " + (i + 1));
			System.out.print("pId: ");
			int pid = scanner.nextInt();
			System.out.print("Price: ");
			double price = scanner.nextDouble();
			System.out.print("Quantity: ");
			int quantity = scanner.nextInt();

			prod[i] = new Product(pid, price, quantity);
		}
		int maxPricePid = getMaxPrice(prod);
		System.out.println("highest price: " + maxPricePid);

		double totalAmountSpent = totalAmountSpent(prod);
		System.out.println("Total amount spent: " + totalAmountSpent);
	}

	public static int getMaxPrice(Product[] prod) {
		double maxPrice = 0;
		int maxPricePid = -1;

		for (Product product : prod) {
			if (product.price > maxPrice) {
				maxPrice = product.price;
				maxPricePid = product.pid;
			}
		}

		return maxPricePid;
	}

	public static double totalAmountSpent(Product[] prod) {
		double totalAmountSpent = 0;

		for (Product product : prod) {
			totalAmountSpent += product.price * product.quantity;
		}

		return totalAmountSpent;
	}
}