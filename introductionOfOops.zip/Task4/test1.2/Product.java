package zen4;

class Product {
	int pid;
	double price;
	int quantity;
	public Product(int pid, double price, int quantity) {
		this.pid = pid;
		this.price = price;
		this.quantity = quantity;
	}
}