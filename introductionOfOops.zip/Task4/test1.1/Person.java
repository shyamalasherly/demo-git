package zen;

public class Person {
	final int age =18;
	void method(String name, int age) {
		System.out.println(name+" "+this.age);
	}
	public static void main(String[] args) {
		Person obj = new Person();
		obj.method("guvi",1);

	}

}
