package zen4;

import java.util.Scanner;

public class Account {
	public int account;
	public int balance;
	Account(){
		System.out.println("Balance "+balance);
	}
	Account(int account,int balance){
		this.account = account;
		this.balance = balance;
	}

	void depositAmt() {
		System.out.println("Enter Deposite amount: ");
		Scanner sc = new Scanner(System.in);
		int deposit_amt = sc.nextInt();
		if(deposit_amt !=0) {
			balance = balance + deposit_amt;
		}
		System.out.println(balance);
	}
	void withdrawAmt() {
		System.out.println("Enter Withdraw amount: ");
		Scanner sc = new Scanner(System.in);
		int withdraw_amt = sc.nextInt();
		if(withdraw_amt !=0) {
			balance = this.balance - withdraw_amt;
		}
		System.out.println(balance);
	}

	void displayBln() {
		System.out.println("Display the balance "+this.balance);
	}
	public static void main(String[] args) {
		Account acc = new Account(01,100);
		//acc.depositAmt();
		acc.withdrawAmt();
		//acc.displayBln();
		
		
	}

}
