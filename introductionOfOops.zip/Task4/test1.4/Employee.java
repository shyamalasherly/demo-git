package zen;

public class Employee extends Person{
	public int employeeId;
	public int salary;
	
	public Employee(String name,int age,int employeeId,int salary) {
		super.name = name;
		super.age = 18;
		this.employeeId = employeeId;
		this.salary = salary;
	}
	void display() {
		System.out.println("Employee Name:"+name+"  Employee Age:"+age+"  EmployeeId:"+employeeId+"  Employee Salary:"+salary);
	}

}
