package zen;

import java.util.Scanner;

public class Person {
	public String name;
	public int age;
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String str = sc.next();
		int age = sc.nextInt();
		int id = sc.nextInt();
		int salary = sc.nextInt();
		Employee obj = new Employee(str,age,id,salary);
		obj.display();
	}

}
