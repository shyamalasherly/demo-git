package zen8;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
public class String_EmptyOrNot {
	public static void main(String[] args) {
		List<String> list = Arrays.asList("abc","","bc", "efg","abcd","","jkl"); 
		List<String> notEmpty = list.stream().filter(x -> !x.isEmpty()).collect(Collectors.toList());
		System.out.println("list of string without empty: "+notEmpty);
	}
}
