package zen8;

import java.util.Arrays;
import java.util.List;

public class Students {
	public static void main(String[] args) {
		List<String> list = Arrays.asList("meeyazh","shyam","anbu","vidhya","magizhan","ivan","amul","idhya","maasha","tiantian"); 
		list.stream().filter(s ->s.startsWith("a")).forEach(System.out::println); 
	}

}
