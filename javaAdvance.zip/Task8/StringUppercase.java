package zen8;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StringUppercase {

	public static void main(String[] args) {
		System.out.println("Convert Strings into uppercase: "); 
		List<String> list = Arrays.asList("aBc", "d", "ef"); 
		List<String> upperStr = list.stream().map(String::toUpperCase).collect(Collectors.toList()); 
		System.out.println(upperStr); 
	} 
} 

