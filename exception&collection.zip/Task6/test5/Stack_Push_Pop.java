package zen6;

import java.util.Stack;

public class Stack_Push_Pop {
	void pushElements() {
		Stack<Integer> stk = new Stack<Integer>();
		stk.push(100);
		stk.push(30);
		stk.push(10);
		stk.push(123);
		stk.push(2);
		System.out.println("pushing elements onto the stack: "+stk);
	}
	void popElements() {
		Stack<Integer> stk = new Stack<Integer>();
		stk.push(100);
		stk.push(30);
		stk.push(2);
		System.out.println("pop elements onto the stack: "+stk.pop());
		System.out.println("Afyer pop stack: "+stk);
	}
	public static void main(String[] args) {

		Stack_Push_Pop obj= new Stack_Push_Pop();
		obj.pushElements();
		obj.popElements();
	}

}
