package zen6;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

public class Students {

	void studentDetails(String str) {
		HashMap<String, Integer> map = new HashMap<>();
		map.put("stu1", 1);
		map.put("stu2", 2);
		map.put("stu3", 3);
		map.put("stu4", 4);
		Iterator<Map.Entry<String, Integer>> itr = map.entrySet().iterator(); 
		//Adding student details to map
		while(itr.hasNext()) 
		{ 
			Map.Entry<String, Integer> entry = itr.next(); 
			System.out.println("student name = " + entry.getKey() +  
					", grade = " + entry.getValue()); 
		}
		//Display up a student's grade by name
		System.out.println("student name to display grade: ");

		for(Entry<String, Integer> entry: map.entrySet()) {

			if(entry.getKey() == str) {
				System.out.println("student grade " + str + " grade is " + entry.getValue());
				break;
			} 
		}	
		//Remove a Students
		System.out.println("removing student: "+str);
		map.remove(str);
	}
	public static void main(String[] args) {
		Students stu = new Students();
		stu.studentDetails("stu4");
	}
}
