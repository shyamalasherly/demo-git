package zen5;

import guvi_codekata.Remove_Duplicate_Space;

public class Library {

	private Book[] book;

	public Library() {
		this.book = new Book[4];
	}

	public void addBook() {
		book[0] = new Book(1, "demo1", "auther1", false);
		book[1] = new Book(2, "demo2", "auther2", true);
		book[2] = new Book(3, "demo3", "auther3", true);
		book[3] = new Book(4, "demo4", "auther4", true);
	}

	public void removeBook(int bookID) {
		for (int i = 0; i < 3; i++) {
			if (book[i].getBookId() == bookID) {
				book[i].setAvailable(false);
				System.out.println("Book removed successfully");
				return;
			}
		}
		System.out.println("Book ID " + bookID + " is not available");
	}

	public void searchBook(int bookId) {
		for(int i=0;i< book.length;i++) {
			if(book[i].getBookId() == bookId) {
				System.out.println(book[i]);
			}
		}
	}
	public void displayAllBook() {
		for(int i=0;i< book.length;i++) {
			System.out.println(book[i].getBookId()+" "+book[i].getTitle()+" "+book[i].getAuther());
		}
	}
}
