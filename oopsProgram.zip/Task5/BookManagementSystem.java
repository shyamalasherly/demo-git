package zen5;

import java.util.Scanner;

public class BookManagementSystem {

	public static void main(String[] args) {
		Library lib = new Library();
		lib.addBook();
		lib.displayAllBook();
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		//lib.searchBook(num);
		
		lib.removeBook(1);
	}

}
